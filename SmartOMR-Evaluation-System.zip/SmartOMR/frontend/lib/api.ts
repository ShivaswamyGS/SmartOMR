const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

export interface User {
  id: number;
  email: string;
  full_name: string;
  role: string;
  is_active: boolean;
}

export interface Exam {
  id: number;
  user_id: number;
  title: string;
  subject: string;
  code?: string;
  total_questions: number;
  marks_per_correct: number;
  negative_marks_per_incorrect: number;
  max_marks: number;
  allow_partial_marking: boolean;
  template_id?: number;
  status: string;
  created_at: string;
  updated_at: string;
  has_answer_key: boolean;
  total_submissions: number;
  average_score: number;
}

export interface AnswerKeyData {
  id: number;
  exam_id: number;
  total_questions: number;
  answers: Record<string, string>;
  custom_weights?: Record<string, number>;
}

export interface EvaluationItem {
  id: number;
  sheet_id: number;
  exam_id: number;
  student_id: string | null;
  student_name: string | null;
  roll_number: string | null;
  total_questions: number;
  correct_count: number;
  incorrect_count: number;
  unanswered_count: number;
  multiple_marked_count: number;
  raw_score: number;
  percentage: number;
  accuracy: number;
  rank: number | null;
  review_status: string;
  created_at: string;
  updated_at: string;
  annotated_image_url?: string;
}

export interface QuestionBreakdownItem {
  question_number: number;
  detected_answer: string | null;
  correct_answer: string | null;
  status: "correct" | "incorrect" | "unanswered" | "multiple_marked";
  confidence: number;
  is_multi_mark: boolean;
  is_ambiguous: boolean;
  fill_ratios: Record<string, number>;
}

export interface ResultDetail {
  id: number;
  sheet_id: number;
  exam_id: number;
  exam_title: string;
  exam_subject: string;
  student_id: string | null;
  student_name: string | null;
  roll_number: string | null;
  total_questions: number;
  correct_count: number;
  incorrect_count: number;
  unanswered_count: number;
  multiple_marked_count: number;
  raw_score: number;
  max_marks: number;
  percentage: number;
  accuracy: number;
  rank: number | null;
  review_status: string;
  file_name: string;
  original_image_url: string;
  annotated_image_url: string;
  question_breakdown: QuestionBreakdownItem[];
  corrections_history: Array<{
    id: number;
    question_number: number;
    old_answer: string | null;
    new_answer: string | null;
    notes: string;
    corrected_by: string;
    created_at: string;
  }>;
}

export function getStoredToken(): string | null {
  if (typeof window === "undefined") return null;
  return localStorage.getItem("smartomr_token");
}

export function setStoredToken(token: string) {
  if (typeof window !== "undefined") {
    localStorage.setItem("smartomr_token", token);
  }
}

export function removeStoredToken() {
  if (typeof window !== "undefined") {
    localStorage.removeItem("smartomr_token");
    localStorage.removeItem("smartomr_user");
  }
}

export function getStoredUser(): User | null {
  if (typeof window === "undefined") return null;
  const raw = localStorage.getItem("smartomr_user");
  try {
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function setStoredUser(user: User) {
  if (typeof window !== "undefined") {
    localStorage.setItem("smartomr_user", JSON.stringify(user));
  }
}

async function fetchWithAuth(endpoint: string, options: RequestInit = {}) {
  const token = getStoredToken();
  const headers = new Headers(options.headers || {});
  
  if (token) {
    headers.set("Authorization", `Bearer ${token}`);
  }
  
  if (!(options.body instanceof FormData) && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }

  const res = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers,
  });

  if (!res.ok) {
    let errorDetail = "An error occurred";
    try {
      const errJson = await res.json();
      errorDetail = errJson.detail || errJson.message || errorDetail;
    } catch {
      errorDetail = `Request failed: ${res.statusText} (${res.status})`;
    }
    throw new Error(errorDetail);
  }

  return res.json();
}

export const api = {
  // Auth
  async login(email: string, password: string) {
    const data = await fetchWithAuth("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    });
    setStoredToken(data.access_token);
    setStoredUser(data.user);
    return data;
  },

  async register(email: string, password: string, fullName: string, role = "teacher") {
    return fetchWithAuth("/api/auth/register", {
      method: "POST",
      body: JSON.stringify({ email, password, full_name: fullName, role }),
    });
  },

  async getMe(): Promise<User> {
    return fetchWithAuth("/api/auth/me");
  },

  logout() {
    removeStoredToken();
  },

  // Dashboard
  async getDashboardStats() {
    return fetchWithAuth("/api/dashboard/stats");
  },

  // Exams
  async listExams(): Promise<Exam[]> {
    return fetchWithAuth("/api/exams");
  },

  async getExam(id: number | string): Promise<Exam> {
    return fetchWithAuth(`/api/exams/${id}`);
  },

  async createExam(data: {
    title: string;
    subject: string;
    code?: string;
    total_questions: number;
    marks_per_correct: number;
    negative_marks_per_incorrect: number;
    max_marks: number;
    template_id?: number;
  }): Promise<Exam> {
    return fetchWithAuth("/api/exams", {
      method: "POST",
      body: JSON.stringify(data),
    });
  },

  // Answer Keys
  async getAnswerKey(examId: number | string): Promise<AnswerKeyData> {
    return fetchWithAuth(`/api/exams/${examId}/answer-key`);
  },

  async saveAnswerKey(examId: number | string, data: {
    total_questions: number;
    answers: Record<string, string>;
    custom_weights?: Record<string, number>;
  }): Promise<AnswerKeyData> {
    return fetchWithAuth(`/api/exams/${examId}/answer-key`, {
      method: "POST",
      body: JSON.stringify(data),
    });
  },

  // Roster
  async uploadRoster(examId: number | string, file: File) {
    const formData = new FormData();
    formData.append("file", file);
    return fetchWithAuth(`/api/exams/${examId}/roster`, {
      method: "POST",
      body: formData,
    });
  },

  async getRoster(examId: number | string) {
    return fetchWithAuth(`/api/exams/${examId}/roster`);
  },

  // OMR Upload & Processing
  async uploadOMRSheets(examId: number | string, files: File[]) {
    const formData = new FormData();
    for (const f of files) {
      formData.append("files", f);
    }
    return fetchWithAuth(`/api/exams/${examId}/upload`, {
      method: "POST",
      body: formData,
    });
  },

  async generateDemoSamples(examId: number | string, count = 5) {
    return fetchWithAuth(`/api/exams/${examId}/generate-samples?count=${count}`, {
      method: "POST",
    });
  },

  async getBatchStatus(batchId: number) {
    return fetchWithAuth(`/api/exams/batches/${batchId}/status`);
  },

  // Results
  async listResults(examId: number | string, params: {
    search?: string;
    status?: string;
    sort_by?: string;
    sort_dir?: string;
    page?: number;
    limit?: number;
  } = {}) {
    const q = new URLSearchParams();
    if (params.search) q.set("search", params.search);
    if (params.status) q.set("status", params.status);
    if (params.sort_by) q.set("sort_by", params.sort_by);
    if (params.sort_dir) q.set("sort_dir", params.sort_dir);
    if (params.page) q.set("page", params.page.toString());
    if (params.limit) q.set("limit", params.limit.toString());
    return fetchWithAuth(`/api/exams/${examId}/results?${q.toString()}`);
  },

  async getResult(resultId: number | string): Promise<ResultDetail> {
    return fetchWithAuth(`/api/results/${resultId}`);
  },

  async correctAnswer(resultId: number | string, questionNumber: number, newAnswer: string | null, notes?: string) {
    return fetchWithAuth(`/api/results/${resultId}/answers`, {
      method: "PUT",
      body: JSON.stringify({ question_number: questionNumber, new_answer: newAnswer, notes }),
    });
  },

  async correctIdentity(resultId: number | string, data: { student_id?: string; student_name?: string; roll_number?: string }) {
    return fetchWithAuth(`/api/results/${resultId}/identity`, {
      method: "PUT",
      body: JSON.stringify(data),
    });
  },

  // Templates
  async listTemplates() {
    return fetchWithAuth("/api/templates");
  },

  getBlankTemplateUrl(templateId: number | string) {
    return `${API_BASE}/api/templates/${templateId}/blank`;
  },

  getExportUrl(examId: number | string, format: "xlsx" | "csv" | "pdf") {
    const token = getStoredToken();
    return `${API_BASE}/api/exams/${examId}/export?format=${format}&token=${token || ''}`;
  },

  getImageUrl(pathSuffix: string) {
    return `${API_BASE}${pathSuffix}`;
  }
};
